package com.heycream.AbstractAndInterface;

public interface PricedItem 
{
    int getPrice();
}
