package com.heycream.AbstractAndInterface;
public interface DessertItem extends NamedItem, PricedItem {}
