package com.heycream.AbstractAndInterface;

public interface NamedItem 
{
    String getName();
}
