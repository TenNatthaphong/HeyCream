package com.heycream.gui;

import javafx.scene.layout.AnchorPane;

public interface HasRootPane 
{
    // =====================
    // SECTION: Methods
    // =====================
    AnchorPane getRootPane();
}
